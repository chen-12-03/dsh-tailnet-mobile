/**
 * Browser-compatibility polyfills for the phone surface. dsh core's client
 * code (`@deepseek-ai/dsh-client-connection`) uses modern Web APIs
 * unconditionally in its fetch carrier — notably `AbortSignal.timeout` for
 * every unary RPC (connection handshake `host.describe`, `workspace.list`,
 * …). A phone browser/WebView older than those APIs throws
 * `AbortSignal.timeout is not a function` inside `postJson`, so the
 * connection never reaches `connected` and the workspace baseline never loads
 * (the R10 phone test caught exactly this error). The fork cannot modify dsh
 * core, but it runs in the SAME page realm — so a small, idempotent polyfill
 * installed at module load (and again in `apply()`) heals the whole client.
 *
 * Covers the APIs the phone (Chrome ~92–102 era: has `crypto.randomUUID`,
 * lacks `AbortSignal.timeout`/`.any`) is likely to hit:
 *   - AbortSignal.timeout / AbortSignal.any   (the confirmed blocker)
 *   - Object.hasOwn, Array.prototype.at, Array.prototype.findLast
 *   - structuredClone (dsh-core LLM `freezeMessage`; a JSON+Date+Map/Set
 *     fallback, exact enough for the chat surface)
 */
/** Install the polyfills; safe to call repeatedly. */
export declare function ensureCompatPolyfills(): void;
//# sourceMappingURL=compat-polyfill.d.ts.map