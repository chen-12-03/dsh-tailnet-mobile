import type { ReactElement } from 'react';
/** Live diagnostic state, keyed by slot name; written by client/index.ts. */
export type FlowDiagEntry = string | (() => void);
export declare const flowDiag: Record<string, FlowDiagEntry>;
/**
 * Self-updating diagnostic toast. Re-renders every 500ms to reflect live
 * `flowDiag` state (registration/connection settling happens async after boot),
 * auto dismisses after 60s, and offers a manual close + manual list refresh.
 */
export declare function FlowDiagToast(): ReactElement | null;
//# sourceMappingURL=FlowDiagToast.d.ts.map