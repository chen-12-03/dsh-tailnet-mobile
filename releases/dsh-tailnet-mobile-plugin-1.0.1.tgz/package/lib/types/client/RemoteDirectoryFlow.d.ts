import type { DirectoryFlowOwnerProps } from '@deepseek-ai/dsh-client-ui-workspace/client';
import type { IWorkspaces } from '@deepseek-ai/dsh-client-runtime/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
/** Full occupant props: owner conversation + the read face of the workspaces service. */
export interface RemoteDirectoryFlowProps extends DirectoryFlowOwnerProps {
    /** Wire-facing workspaces service; the registered list is read from it. */
    workspaces: IWorkspaces;
    /** Re-pull the workspace baseline; supplied by the fork plugin's inject. */
    refresh?: () => Promise<unknown>;
    /** Locale seat bound to the `remote` namespace. */
    t: TranslateNS<'remote'>;
}
/**
 * Render the remote workspace picker.
 * @param props - owner conversation + workspaces read face.
 * @returns a fixed overlay listing registered workspaces, or nothing while closed.
 */
export declare function RemoteDirectoryFlow({ open, busy, onPicked, onCancel, onError, workspaces, refresh, t }: RemoteDirectoryFlowProps): import("react").ReactPortal | null;
//# sourceMappingURL=RemoteDirectoryFlow.d.ts.map