/**
 * The mobile surface's data channel: `/m/api` proxies the host ApiProxy
 * service for the standalone phone page. The phone's RPC calls ride THIS
 * prefix instead of the connection plugin's `/api` — so the tunneled Host
 * never needs to enter the connection trust fence (a distributable plugin
 * cannot change that fence), and this plugin's own pairing gate is the
 * access control instead.
 *
 * Security model:
 * - Every request must carry a live paired-device cookie (the same gate
 *   semantic as the LAN fence), enforced before any host call.
 * - Only an explicit allowlist of methods is proxied; privileged domains
 *   (settings, credentials, host actions, goals, subagents, …) are never
 *   reachable from the phone.
 * - `session.list` is paged here (the host API returns everything; this
 *   layer slices stable pages) so the phone never transfers the whole list.
 * - The live mux stream is bridged over Server-Sent Events on the same
 *   prefix (one-directional push; answers to questions/approvals ride the
 *   unary channel), gated identically.
 */
import type { IncomingMessage } from 'node:http';
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
import type { ApiProxy } from '@deepseek-ai/dsh-host-apiproxy';
import type { PairingService } from './pairing.ts';
/** Minimal dsh-cost-meter service face exposed to the mobile surface. */
export interface MobileCostMeterService {
    getState(): Promise<unknown>;
    refreshBalance(): Promise<unknown>;
}
/** Route-family dependencies. */
export interface MobileApiDeps {
    /** The pairing service (device gate + cookie name). */
    service: PairingService;
    /** The host ApiProxy service (injected by the plugin). */
    apiProxy: ApiProxy;
    /** The resolved mobile composer preference (live per request). */
    mobileEnterToSend: () => boolean;
    /** Tailscale Serve app capability allowed to use /m/api without pairing. */
    tailnetCapability?: () => string;
    /** Process-local verifier for requests forwarded by the opt-in LAN bridge. */
    trustedLanBridgeRequest?: (req: IncomingMessage) => boolean;
    /** Optional dsh-cost-meter host service (undefined when not installed). */
    costMeter?: () => MobileCostMeterService | undefined;
    /** SSE keep-alive ping cadence for the mux stream (default 15000 ms; test seam). */
    eventsHeartbeatMs?: number;
}
/** Mobile API route paths. */
export declare const MOBILE_API_PATHS: {
    readonly events: "/m/api/events.mux";
};
/**
 * Tailscale Serve capability bypass for the mobile data channel.
 *
 * Serve strips caller-supplied Tailscale identity/capability headers before it
 * injects the peer's granted capabilities. The backend still requires a
 * loopback proxy connection and browser same-origin markers, so a LAN caller
 * cannot forge this bypass by supplying the header directly.
 */
export declare function isTrustedTailnetCapabilityRequest(req: IncomingMessage, capability: string): boolean;
/**
 * Tailscale Serve identity bypass for the mobile data channel.
 *
 * Tailscale Serve injects authenticated Tailnet user headers on the loopback
 * hop. This lets a phone on the Tailnet open `/m` without configuring an app
 * capability or pairing cookie; the mobile channel remains method-allowlisted
 * and the request must still come from loopback with a same-origin browser
 * marker. The LAN bridge strips these headers, so this path is only reachable
 * through an actual Tailscale Serve proxy.
 */
export declare function isTrustedTailnetServeRequest(req: IncomingMessage): boolean;
/**
 * Loopback reverse-proxy bypass for the mobile data channel.
 *
 * Tailscale Serve (and other local reverse proxies) terminate the Tailnet
 * HTTPS connection and forward to this process over loopback. This fallback
 * accepts a loopback request with a browser same-origin marker even when the
 * Serve build does not inject Tailnet identity headers. The mobile channel
 * stays method-allowlisted; this only changes the transport gate from
 * "paired cookie / capability / identity header" to also trust the local
 * reverse proxy hop.
 */
export declare function isTrustedLoopbackProxyRequest(req: IncomingMessage): boolean;
/**
 * Build the mobile data-channel routes.
 * @param deps - pairing service + apiProxy.
 * @returns the routes to register on webServer.
 */
export declare function makeMobileApiRoutes(deps: MobileApiDeps): WebRoute[];
//# sourceMappingURL=mobile-api.d.ts.map