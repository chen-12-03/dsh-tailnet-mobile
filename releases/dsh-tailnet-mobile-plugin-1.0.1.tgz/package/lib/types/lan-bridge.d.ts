/**
 * Opt-in LAN bridge for the standalone mobile surface.
 *
 * DSH intentionally keeps its main web server on loopback. This bridge opens
 * a separate listener that proxies only `/m` and `/m/*`, rejects clients
 * outside an explicit IPv4/CIDR allowlist, strips Tailscale identity headers,
 * and marks the internal hop with an unguessable process-local secret.
 */
import { type IncomingMessage } from 'node:http';
/** Header used only on the bridge-to-loopback hop. */
export declare const LAN_BRIDGE_HEADER = "x-dsh-lan-bridge-secret";
/** Runtime configuration for the optional listener. */
export interface LanBridgeConfig {
    enabled: boolean;
    port: number;
    allowedCidrs: string;
}
/** Whether a remote IPv4 address belongs to the comma/newline-separated allowlist. */
export declare function isAllowedLanAddress(remoteAddress: string | undefined, allowedCidrs: string): boolean;
/** Verify the process-local marker on the loopback side of the bridge. */
export declare function isTrustedLanBridgeRequest(req: IncomingMessage, secret: string): boolean;
/** Lifecycle wrapper used by the host plugin settings synchronizer. */
export declare class LanMobileBridge {
    private readonly targetPort;
    private readonly secret;
    private server;
    private activeKey;
    constructor(targetPort: number, secret: string);
    sync(config: LanBridgeConfig): void;
    stop(): void;
}
//# sourceMappingURL=lan-bridge.d.ts.map